"""
SQLite + NumPy 极简存储实现
替代 PostgreSQL + pgvector，用于 MVP 验证
"""
import sqlite3
import numpy as np
import json
from typing import List, Optional
from dataclasses import dataclass
from datetime import datetime


@dataclass
class PendingDemand:
    demand_id: str
    resource_type: str
    description: str
    tags: List[str]
    demand_vector: List[float]  # 👈 必须要有向量字段
    seeker_id: Optional[str]
    seeker_webhook_url: str  # 👈 [新增] 绝对的公网收货地址
    created_at: str
    status: str = "pending"
    matched_agent_id: Optional[str] = None


class LiteMemoryRepository:
    """SQLite + NumPy 极简存储"""

    def __init__(self, db_path: str = "hub_mvp.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """初始化数据库表"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS pending_demands (
                    demand_id TEXT PRIMARY KEY,
                    resource_type TEXT,
                    description TEXT,
                    tags TEXT,
                    demand_vector TEXT,  -- 👈 存 JSON 格式的浮点数数组
                    seeker_id TEXT,
                    seeker_webhook_url TEXT,  -- 👈 [新增] 绝对的公网收货地址
                    created_at TEXT,
                    status TEXT DEFAULT 'pending',
                    matched_agent_id TEXT
                )
            """)

    def add_demand(self, demand: PendingDemand) -> PendingDemand:
        """添加悬赏需求"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO pending_demands
                (demand_id, resource_type, description, tags, demand_vector, seeker_id, seeker_webhook_url, created_at, status, matched_agent_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                demand.demand_id,
                demand.resource_type,
                demand.description,
                json.dumps(demand.tags),
                json.dumps(demand.demand_vector),  # 👈 向量转 JSON 存入
                demand.seeker_id,
                demand.seeker_webhook_url,  # 👈 [新增] 公网收货地址
                demand.created_at,
                demand.status,
                demand.matched_agent_id
            ))
        return demand

    def _cosine_similarity(self, vec_a: List[float], vec_b: List[float]) -> float:
        """真正的 NumPy 极速余弦相似度计算"""
        a, b = np.array(vec_a), np.array(vec_b)
        if np.linalg.norm(a) == 0 or np.linalg.norm(b) == 0:
            return 0.0
        return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))

    def find_matches(self, new_tags: List[str], new_vector: List[float], threshold: float = 0.7) -> List[PendingDemand]:
        """标签初筛 + NumPy 向量精筛"""
        print(f"[DEBUG-REPO] ========== Finding Matches ==========")
        print(f"[DEBUG-REPO] New tags: {new_tags}")
        print(f"[DEBUG-REPO] Threshold: {threshold}")

        matches = []
        with sqlite3.connect(self.db_path) as conn:
            # ⚠️ 修正：明确写出列名，严格控制顺序（避免 SELECT * 导致的列索引偏移）
            cursor = conn.execute("""
                SELECT demand_id, resource_type, description, tags, demand_vector,
                       seeker_id, seeker_webhook_url, created_at, status, matched_agent_id
                FROM pending_demands WHERE status = 'pending'
            """)
            for row in cursor.fetchall():
                demand = PendingDemand(
                    demand_id=row[0],
                    resource_type=row[1],
                    description=row[2],
                    tags=json.loads(row[3]),
                    demand_vector=json.loads(row[4]),
                    seeker_id=row[5],
                    seeker_webhook_url=row[6],  # 👈 [新增] 接收新字段
                    created_at=row[7],           # 原本是 row[6]，现在偏移到 row[7]
                    status=row[8],               # 原本是 row[7]
                    matched_agent_id=row[9]     # 原本是 row[8]
                )

                # 1. 标签交集初筛 (加速)
                tag_intersection = set(new_tags).intersection(set(demand.tags))
                if not tag_intersection:
                    print(f"[DEBUG-REPO] ✗ {demand.demand_id}: No tag intersection (demand_tags={demand.tags})")
                    continue

                print(f"[DEBUG-REPO]   {demand.demand_id}: Tag intersection = {tag_intersection}")

                # 2. NumPy 向量计算相似度
                sim = self._cosine_similarity(demand.demand_vector, new_vector)
                print(f"[DEBUG-REPO]   {demand.demand_id}: Similarity = {sim:.4f} (threshold={threshold})")

                if sim >= threshold:
                    print(f"[DEBUG-REPO]   ✓ {demand.demand_id}: MATCHED!")
                    matches.append((demand, sim))
                else:
                    print(f"[DEBUG-REPO]   ✗ {demand.demand_id}: Below threshold")

        # 按相似度降序排序并返回
        matches.sort(key=lambda x: x[1], reverse=True)
        print(f"[DEBUG-REPO] Total matches: {len(matches)}")
        print(f"[DEBUG-REPO] ========================================")
        return [m[0] for m in matches]

    def mark_matched(self, demand_id: str, agent_id: str):
        """标记为已匹配"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "UPDATE pending_demands SET status = 'matched', matched_agent_id = ? WHERE demand_id = ?",
                (agent_id, demand_id)
            )

    def get_matched_demands_for_seeker(self, seeker_id: str) -> List[PendingDemand]:
        """查询指定 Seeker 的已匹配待收货订单"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT demand_id, resource_type, description, tags, demand_vector,
                       seeker_id, seeker_webhook_url, created_at, status, matched_agent_id
                FROM pending_demands
                WHERE seeker_id = ? AND status = 'matched'
            """, (seeker_id,))
            demands = []
            for row in cursor.fetchall():
                demands.append(PendingDemand(
                    demand_id=row[0],
                    resource_type=row[1],
                    description=row[2],
                    tags=json.loads(row[3]),
                    demand_vector=json.loads(row[4]),
                    seeker_id=row[5],
                    seeker_webhook_url=row[6],
                    created_at=row[7],
                    status=row[8],
                    matched_agent_id=row[9]
                ))
            return demands

    def get_matched_demands_for_provider(self, provider_id: str) -> List[PendingDemand]:
        """查询指定 Provider 的已匹配待发货订单"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT demand_id, resource_type, description, tags, demand_vector,
                       seeker_id, seeker_webhook_url, created_at, status, matched_agent_id
                FROM pending_demands
                WHERE matched_agent_id = ? AND status = 'matched'
            """, (provider_id,))
            demands = []
            for row in cursor.fetchall():
                demands.append(PendingDemand(
                    demand_id=row[0],
                    resource_type=row[1],
                    description=row[2],
                    tags=json.loads(row[3]),
                    demand_vector=json.loads(row[4]),
                    seeker_id=row[5],
                    seeker_webhook_url=row[6],
                    created_at=row[7],
                    status=row[8],
                    matched_agent_id=row[9]
                ))
            return demands

    def get_all_pending(self) -> List[PendingDemand]:
        """获取所有待处理需求"""
        with sqlite3.connect(self.db_path) as conn:
            # ⚠️ 修正：同样需要明确字段列表（避免 SELECT * 导致的列索引偏移）
            cursor = conn.execute("""
                SELECT demand_id, resource_type, description, tags, demand_vector,
                       seeker_id, seeker_webhook_url, created_at, status, matched_agent_id
                FROM pending_demands WHERE status = 'pending'
            """)
            demands = []
            for row in cursor.fetchall():
                demands.append(PendingDemand(
                    demand_id=row[0],
                    resource_type=row[1],
                    description=row[2],
                    tags=json.loads(row[3]),
                    demand_vector=json.loads(row[4]),
                    seeker_id=row[5],
                    seeker_webhook_url=row[6],  # 👈 [新增] 接收新字段
                    created_at=row[7],           # 原本是 row[6]
                    status=row[8],               # 原本是 row[7]
                    matched_agent_id=row[9]     # 原本是 row[8]
                ))
            return demands

    def delete_demand(self, demand_id: str) -> bool:
        """
        V1.6: 删除需求

        当用户主动取消时，删除云端记录。

        Args:
            demand_id: 需求 ID

        Returns:
            True 如果删除成功，False 如果需求不存在
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "DELETE FROM pending_demands WHERE demand_id = ?",
                (demand_id,)
            )
            return cursor.rowcount > 0

    def get_expired_demands(self, older_than_days: int = 60) -> List[PendingDemand]:
        """
        V1.6: 获取过期需求

        用于 Hub 主动发送过期通知。

        Args:
            older_than_days: 超过多少天算过期（默认 60 天）

        Returns:
            过期的需求列表
        """
        from datetime import timedelta

        cutoff = datetime.utcnow() - timedelta(days=older_than_days)
        cutoff_str = cutoff.isoformat()

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT demand_id, resource_type, description, tags, demand_vector,
                       seeker_id, seeker_webhook_url, created_at, status, matched_agent_id
                FROM pending_demands
                WHERE status = 'pending' AND created_at < ?
            """, (cutoff_str,))
            demands = []
            for row in cursor.fetchall():
                demands.append(PendingDemand(
                    demand_id=row[0],
                    resource_type=row[1],
                    description=row[2],
                    tags=json.loads(row[3]),
                    demand_vector=json.loads(row[4]),
                    seeker_id=row[5],
                    seeker_webhook_url=row[6],
                    created_at=row[7],
                    status=row[8],
                    matched_agent_id=row[9]
                ))
            return demands


# 单例实例
_repo = LiteMemoryRepository()


def get_repository() -> LiteMemoryRepository:
    return _repo
