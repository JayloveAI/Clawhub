"""
Match Service - 向量语义撮合服务
================================
负责向量化处理和语义相似度检索

支持: OpenAI / GLM-5 (智谱)

V1.5 Updates:
- Hybrid search with node_status filtering
- Live broadcast vector regeneration
- SQL performance optimizations
"""
import httpx
from typing import Optional, Literal, List
from datetime import datetime
from hub_server.config import (
    EMBEDDING_API_KEY, EMBEDDING_MODEL,
    EMBEDDING_PROVIDER, EMBEDDING_DIMENSIONS,
    SIMILARITY_THRESHOLD
)


class EmbeddingService:
    """Embedding 服务 - 支持 OpenAI 和 GLM-5"""

    # API 提供商配置
    PROVIDERS = {
        "openai": {
            "url": "https://api.openai.com/v1/embeddings",
            "model": "text-embedding-ada-002",
            "dimensions": 1536
        },
        "glm": {
            "url": "https://open.bigmodel.cn/api/paas/v4/embeddings",
            "model": "embedding-2",
            "dimensions": 1024
        }
    }

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        provider: Optional[Literal["openai", "glm"]] = None
    ):
        self.api_key = api_key or EMBEDDING_API_KEY
        self.model = model or EMBEDDING_MODEL
        self.provider = provider or EMBEDDING_PROVIDER
        self.config = self.PROVIDERS[self.provider]

    async def get_embedding(self, text: str) -> List[float]:
        """
        获取文本的向量表示

        关键决策：在 Hub 服务端进行向量化
        - 客户端无需配置 API Key
        - 降低接入门槛，符合"极简"原则
        """
        if not self.api_key:
            raise ValueError("EMBEDDING_API_KEY 未配置")

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    self.config["url"],
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": self.model,
                        "input": text
                    }
                )
                response.raise_for_status()

                data = response.json()

                # GLM 和 OpenAI 响应格式略有不同
                if self.provider == "glm":
                    return data["data"][0]["embedding"]
                else:
                    return data["data"][0]["embedding"]

        except httpx.HTTPError as e:
            raise RuntimeError(f"Embedding API 调用失败 ({self.provider}): {str(e)}")
    
    async def batch_get_embeddings(self, texts: List[str]) -> List[List[float]]:
        """批量获取向量（优化 API 调用次数）"""
        if not texts:
            return []

        if not self.api_key:
            raise ValueError("EMBEDDING_API_KEY 未配置")

        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    self.config["url"],
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": self.model,
                        "input": texts
                    }
                )
                response.raise_for_status()

                data = response.json()
                return [item["embedding"] for item in data["data"]]

        except httpx.HTTPError as e:
            raise RuntimeError(f"批量 Embedding API 调用失败 ({self.provider}): {str(e)}")


class MatchService:
    """撮合服务 - 向量检索 + 业务过滤"""
    
    def __init__(self, db_conn, embedding_service: EmbeddingService):
        self.db = db_conn
        self.embedding = embedding_service
    
    async def publish_agent(
        self,
        agent_id: str,
        domain: str,
        intent_type: str,
        contact_endpoint: str,
        description: str
    ) -> dict:
        """
        发布/更新 Agent 名片
        
        1. 对 description 进行向量化
        2. 存入数据库
        3. 返回注册结果
        """
        # 服务端负责向量化（关键决策点）
        description_vector = await self.embedding.get_embedding(description)
        
        # TODO: 实现数据库存储逻辑
        # 这里需要集成 SQLAlchemy 或 asyncpg
        
        return {
            "agent_id": agent_id,
            "status": "registered",
            "vector_dim": len(description_vector)
        }
    
    async def search_agents(
        self,
        query: str,
        domain: Optional[str] = None,
        top_k: int = 3
    ) -> List[dict]:
        """
        V1.5 Hybrid Search: SQL hard filter + vector soft rank

        Strategy:
        1. SQL WHERE: domain = ? AND node_status = 'active' (hard filter)
        2. pgvector ORDER BY: <=> cosine distance (soft ranking)
        3. Performance: SET LOCAL enable_seqscan = off for HNSW index usage

        Returns agents with:
        - agent_id, contact_endpoint, tasks_provided
        - node_status, live_broadcast
        - similarity_score (0-1)
        """
        # 1. 向量化查询
        query_vector = await self.embedding.get_embedding(query)

        # 2. V1.5 Hybrid Search with node_status filtering
        # Performance: Disable sequential scan to ensure HNSW index is used
        sql = """
            SET LOCAL enable_seqscan = off;

            SELECT
                agent_id,
                contact_endpoint,
                tasks_provided,
                node_status,
                live_broadcast,
                1 - (description_vector <=> $1::vector) AS similarity
            FROM agent_profiles
            WHERE intent_type = 'bid'
              AND node_status = 'active'
        """

        params = [query_vector]

        if domain:
            sql += " AND domain = $2"
            params.append(domain)

        sql += """
            AND 1 - (description_vector <=> $1::vector) > $3
            ORDER BY description_vector <=> $1::vector
            LIMIT $4
        """

        params.extend([SIMILARITY_THRESHOLD, top_k])

        # TODO: 执行数据库查询
        # results = await self.db.fetch(sql, *params)

        # 返回模拟结果（开发调试用）
        return [
            {
                "agent_id": "english_corpus_bot",
                "contact_endpoint": "https://example.ngrok.app/api/webhook",
                "match_token": "mock.jwt.token",
                "tasks_provided": 342,
                "node_status": "active",
                "live_broadcast": "[空闲中] 算力充足，接单秒回",
                "similarity_score": 0.92
            }
        ]

    async def update_status(
        self,
        agent_id: str,
        node_status: Literal["active", "busy", "offline"],
        live_broadcast: Optional[str] = None
    ) -> dict:
        """
        V1.5 Update agent live status and regenerate search vector

        Key Design:
        - node_status: For SQL WHERE filtering (hard filter)
        - live_broadcast: Combined with identity for vector embedding (soft ranking)

        Vector = identity_text + live_broadcast
        This makes search results reflect current agent availability
        """
        # TODO: Get agent profile from database
        # agent = await self.db.fetch_one(
        #     "SELECT description FROM agent_profiles WHERE agent_id = $1",
        #     agent_id
        # )
        # if not agent:
        #     raise ValueError(f"Agent {agent_id} not found")

        # For now, use mock description
        description = "Mock agent description"

        # Combine identity + live_broadcast for vectorization
        combined_text = f"{description}\n\nBroadcast: {live_broadcast or 'No message'}"
        new_vector = await self.embedding.get_embedding(combined_text)

        # TODO: Update database
        # await self.db.execute("""
        #     UPDATE agent_profiles
        #     SET
        #         node_status = $1,
        #         live_broadcast = $2,
        #         status_updated_at = NOW(),
        #         description_vector = $3
        #     WHERE agent_id = $4
        # """, node_status, live_broadcast, new_vector, agent_id)

        return {
            "agent_id": agent_id,
            "node_status": node_status,
            "live_broadcast": live_broadcast,
            "status_updated_at": datetime.utcnow().isoformat(),
            "vector_regenerated": True
        }


# 全局单例（在应用启动时初始化）
# 根据 EMBEDDING_PROVIDER 配置自动选择提供商
embedding_service = EmbeddingService(
    api_key=EMBEDDING_API_KEY,
    model=EMBEDDING_MODEL,
    provider=EMBEDDING_PROVIDER
)
