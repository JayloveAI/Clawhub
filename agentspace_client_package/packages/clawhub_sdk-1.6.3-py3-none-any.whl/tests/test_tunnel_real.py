"""
真实隧道启动与跨设备 P2P 测试
================================

测试目标：
1. 验证 Ngrok 隧道启动
2. 验证 FRP 隧道启动（需要 FRP 服务器）
3. 测试公网 Webhook URL 组装
4. 模拟跨设备 P2P 文件投递

前置条件：
- Ngrok: 需要 NGROK_AUTHTOKEN 环境变量
- FRP: 需要 FRP_SERVER_ADDR 和 FRP_TOKEN
"""

import asyncio
import os
import sys
from pathlib import Path

# Fix Windows console encoding
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from client_sdk.tunnel.manager import TunnelManager, TunnelProvider
from client_sdk.tunnel.ngrok_impl import NgrokTunnel
from client_sdk.tunnel.frp_impl import FrpTunnel


class TunnelTestSuite:
    """隧道测试套件"""

    def __init__(self):
        self.test_port = 8000
        self.results = []

    def log(self, message: str, status: str = "INFO"):
        """格式化日志输出"""
        symbols = {
            "INFO": "[INFO]",
            "OK": "[OK]  ",
            "WARN": "[WARN]",
            "ERROR": "[ERR]",
            "SKIP": "[SKIP]",
        }
        print(f"{symbols.get(status, '[----]')} {message}")
        self.results.append((status, message))

    def check_environment(self) -> dict:
        """检查环境配置"""
        env_status = {
            "ngrok_token": bool(os.getenv("NGROK_AUTHTOKEN")),
            "frp_server": bool(os.getenv("FRP_SERVER_ADDR")),
            "frp_token": bool(os.getenv("FRP_TOKEN")),
        }
        return env_status

    async def test_ngrok_startup(self) -> bool:
        """测试 Ngrok 隧道启动"""
        self.log("\n[Test 1] Ngrok 隧道启动测试", "INFO")
        self.log("-" * 40, "INFO")

        if not os.getenv("NGROK_AUTHTOKEN"):
            self.log("NGROK_AUTHTOKEN 未设置，跳过 Ngrok 测试", "WARN")
            self.log("获取方法: 访问 https://dashboard.ngrok.com/get-started/your-authtoken", "INFO")
            self.log("设置方法: export NGROK_AUTHTOKEN='your_token_here'", "INFO")
            return False

        try:
            tunnel = NgrokTunnel(
                auth_token=os.getenv("NGROK_AUTHTOKEN"),
                region=os.getenv("NGROK_REGION", "us")
            )

            self.log(f"正在启动 Ngrok 隧道 (端口 {self.test_port})...", "INFO")
            public_url = await tunnel.start(self.test_port)

            self.log(f"Ngrok 隧道启动成功！", "OK")
            self.log(f"公网地址: {public_url}", "INFO")
            self.log(f"收货 Webhook: {public_url}/api/webhook/delivery", "INFO")

            # 测试完成后关闭
            await asyncio.sleep(2)
            tunnel.stop()
            self.log("Ngrok 隧道已关闭", "INFO")
            return True

        except Exception as e:
            self.log(f"Ngrok 启动失败: {e}", "ERROR")
            self.log("可能原因:", "INFO")
            self.log("  1. 网络连接问题", "INFO")
            self.log("  2. Ngrok 账户限制", "INFO")
            self.log("  3. 防火墙阻止", "INFO")
            return False

    async def test_frp_startup(self) -> bool:
        """测试 FRP 隧道启动"""
        self.log("\n[Test 2] FRP 隧道启动测试", "INFO")
        self.log("-" * 40, "INFO")

        if not os.getenv("FRP_SERVER_ADDR"):
            self.log("FRP_SERVER_ADDR 未设置，跳过 FRP 测试", "WARN")
            self.log("需要配置腾讯云 FRP 服务器地址", "INFO")
            return False

        try:
            tunnel = FrpTunnel(
                server_addr=os.getenv("FRP_SERVER_ADDR", "127.0.0.1"),
                server_port=int(os.getenv("FRP_SERVER_PORT", "7000")),
                token=os.getenv("FRP_TOKEN")
            )

            self.log(f"正在启动 FRP 隧道 (端口 {self.test_port})...", "INFO")
            public_url = await tunnel.start(self.test_port)

            self.log(f"FRP 隧道启动成功！", "OK")
            self.log(f"公网地址: {public_url}", "INFO")
            self.log(f"收货 Webhook: {public_url}/api/webhook/delivery", "INFO")

            await asyncio.sleep(2)
            tunnel.stop()
            self.log("FRP 隧道已关闭", "INFO")
            return True

        except Exception as e:
            self.log(f"FRP 启动失败: {e}", "ERROR")
            self.log("可能原因:", "INFO")
            self.log("  1. FRP 服务器不可达", "INFO")
            self.log("  2. 认证 Token 错误", "INFO")
            self.log("  3. 端口已被占用", "INFO")
            return False

    async def test_tunnel_manager_lifecycle(self) -> bool:
        """测试 TunnelManager 完整生命周期"""
        self.log("\n[Test 3] TunnelManager 生命周期测试", "INFO")
        self.log("-" * 40, "INFO")

        # 模拟配置文件中的 public_tunnel_url
        mock_public_url = "https://abc123.ngrok.app"

        # 创建 TunnelManager 实例
        manager = TunnelManager(port=self.test_port)

        # 测试状态属性
        self.log(f"TunnelManager 已初始化 (端口: {self.test_port})", "OK")
        self.log(f"public_url 属性: {manager.public_url}", "INFO")

        # 模拟设置 public_url（真实场景中由 start() 方法设置）
        manager._public_url = mock_public_url

        # 测试 URL 组装（模拟 router.py 中的逻辑）
        webhook_url = f"{manager.public_url}/api/webhook/delivery"
        self.log(f"收货 Webhook URL: {webhook_url}", "INFO")

        return True

    async def test_cross_device_p2p_simulation(self) -> bool:
        """模拟跨设备 P2P 流程"""
        self.log("\n[Test 4] 跨设备 P2P 流程模拟", "INFO")
        self.log("-" * 40, "INFO")

        # 场景：Seeker (设备 A) 通过 Ngrok 暴露服务
        seeker_webhook_url = "https://abc123.ngrok.app/api/webhook/delivery"

        # 场景：Provider (设备 B) 获取到匹配需求
        matched_demand = {
            "demand_id": "demo-demand-001",
            "resource_type": "csv",
            "description": "销售数据报表",
            "seeker_webhook_url": seeker_webhook_url,
        }

        self.log("场景设定:", "INFO")
        self.log(f"  Seeker (设备 A): {seeker_webhook_url}", "INFO")
        self.log(f"  Provider (设备 B): 准备投递文件", "INFO")
        self.log(f"  需求 ID: {matched_demand['demand_id']}", "INFO")

        # 验证 URL 结构
        if not matched_demand["seeker_webhook_url"]:
            self.log("❌ 缺少收货地址！", "ERROR")
            return False

        self.log("✓ 收货地址验证通过", "OK")
        self.log(f"✓ Provider 可以直接向 {seeker_webhook_url} 发送 HTTP POST", "INFO")
        self.log("✓ 无需经过 Hub 服务器转发", "INFO")

        return True

    async def run_all_tests(self):
        """运行所有测试"""
        self.log("=" * 50, "INFO")
        self.log("ClawHub V1.5 隧道无关化测试套件", "INFO")
        self.log("=" * 50, "INFO")

        # 环境检查
        env = self.check_environment()
        self.log("\n[环境检查]", "INFO")
        self.log(f"Ngrok Token: {'✓ 已配置' if env['ngrok_token'] else '✗ 未配置'}", "OK" if env['ngrok_token'] else "WARN")
        self.log(f"FRP Server: {'✓ 已配置' if env['frp_server'] else '✗ 未配置'}", "OK" if env['frp_server'] else "WARN")
        self.log(f"FRP Token: {'✓ 已配置' if env['frp_token'] else '✗ 未配置'}", "OK" if env['frp_token'] else "WARN")

        # 运行测试
        results = []

        # Test 1: Ngrok 启动
        if env['ngrok_token']:
            results.append(await self.test_ngrok_startup())
        else:
            self.log("\n[Test 1] Ngrok 测试已跳跳 (未配置 Token)", "SKIP")
            results.append(None)

        # Test 2: FRP 启动
        if env['frp_server']:
            results.append(await self.test_frp_startup())
        else:
            self.log("\n[Test 2] FRP 测试已跳过 (未配置服务器)", "SKIP")
            results.append(None)

        # Test 3: 生命周期
        results.append(await self.test_tunnel_manager_lifecycle())

        # Test 4: P2P 模拟
        results.append(await self.test_cross_device_p2p_simulation())

        # 总结
        self.log("\n" + "=" * 50, "INFO")
        self.log("[测试总结]", "INFO")

        passed = sum(1 for r in results if r is True)
        failed = sum(1 for r in results if r is False)
        skipped = sum(1 for r in results if r is None)

        self.log(f"通过: {passed}", "OK")
        self.log(f"失败: {failed}", "ERROR" if failed > 0 else "INFO")
        self.log(f"跳过: {skipped}", "WARN" if skipped > 0 else "INFO")

        if failed == 0:
            self.log("\n✓ 所有核心功能验证通过！", "OK")
            self.log("系统已准备好进行跨设备 P2P 协作", "INFO")

            if skipped > 0:
                self.log("\n要完成完整测试，请配置:", "WARN")
                if not env['ngrok_token']:
                    self.log("  - NGROK_AUTHTOKEN (用于 Ngrok 隧道)", "INFO")
                if not env['frp_server']:
                    self.log("  - FRP_SERVER_ADDR (用于 FRP 隧道)", "INFO")
        else:
            self.log("\n✗ 部分测试失败，请检查错误信息", "ERROR")


async def main():
    """主测试入口"""
    suite = TunnelTestSuite()
    await suite.run_all_tests()


if __name__ == "__main__":
    asyncio.run(main())
