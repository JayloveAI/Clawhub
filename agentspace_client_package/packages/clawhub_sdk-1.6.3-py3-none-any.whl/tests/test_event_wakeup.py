﻿import sys
import asyncio
from pathlib import Path

import pytest


sys.path.insert(0, str(Path(__file__).parent.parent))

from client_sdk.gateway.router import UniversalResourceGateway


@pytest.mark.asyncio
async def test_trigger_delivery_sets_event():
    gateway = UniversalResourceGateway()
    demand_id = "demand-test-1"

    event = asyncio.Event()
    gateway._delivery_events[demand_id] = event

    gateway.trigger_delivery(demand_id, "/tmp/result.csv")

    assert event.is_set()
    assert gateway._delivery_results[demand_id] == "/tmp/result.csv"
