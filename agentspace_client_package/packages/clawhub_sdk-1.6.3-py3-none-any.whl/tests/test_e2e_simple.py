"""
AgentHub V1.5 Simple E2E Test
================================
Tests basic functionality without emoji/unicode issues
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


class SimpleTestAgent:
    """Simplified test agent without Rich/emoji dependencies"""

    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        self.received_tasks = []

    async def task_handler(self, task_type: str, task_context: dict):
        """Handle incoming tasks"""
        print(f"\n[Received] Task: {task_type}")
        print(f"[Context] {task_context}")

        # Record task
        self.received_tasks.append({
            "task_type": task_type,
            "context": task_context
        })

        # Process task
        result = await self._process_task(task_type, task_context)
        print(f"[Completed] {result}")
        return result

    async def _process_task(self, task_type: str, context: dict):
        """Actual task processing logic"""
        await asyncio.sleep(0.1)  # Simulate processing

        if task_type == "clean_text":
            raw_text = context.get("text", "")
            cleaned = " ".join(raw_text.split())
            return {
                "status": "success",
                "original_length": len(raw_text),
                "cleaned_length": len(cleaned),
                "cleaned_text": cleaned[:100] + "..." if len(cleaned) > 100 else cleaned
            }
        elif task_type == "format_markdown":
            return {
                "status": "success",
                "formatted": "# Formatted Content\n\n" + context.get("text", "")[:100]
            }
        else:
            return {
                "status": "error",
                "message": f"Unknown task type: {task_type}"
            }


async def test_task_processing():
    """Test basic task processing"""
    print("=" * 60)
    print("  AgentHub V1.5 Simple Test")
    print("=" * 60)

    agent = SimpleTestAgent("test_agent")

    # Test 1: clean_text
    print("\n[Test 1] clean_text")
    result1 = await agent.task_handler(
        "clean_text",
        {"text": "  Hello    World!   This  is  a  test.  " * 10}
    )
    assert result1["status"] == "success"
    assert result1["original_length"] > result1["cleaned_length"]

    # Test 2: format_markdown
    print("\n[Test 2] format_markdown")
    result2 = await agent.task_handler(
        "format_markdown",
        {"text": "# Test Content\n\nSome text here"}
    )
    assert result2["status"] == "success"

    # Test 3: unknown task
    print("\n[Test 3] unknown task")
    result3 = await agent.task_handler(
        "unknown_task",
        {}
    )
    assert result3["status"] == "error"

    # Test 4: concurrent tasks
    print("\n[Test 4] concurrent tasks")
    tasks = [
        agent.task_handler(f"task_{i}", {"index": i})
        for i in range(5)
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    print(f"[Completed] {len([r for r in results if not isinstance(r, Exception)])} concurrent tasks")

    print("\n" + "=" * 60)
    print(f"  All Tests Passed! OK")
    print(f"  Total tasks received: {len(agent.received_tasks)}")
    print("=" * 60)


if __name__ == "__main__":
    print("Starting simple E2E test...\n")
    asyncio.run(test_task_processing())
