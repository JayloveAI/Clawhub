"""
验收测试：隔离与连通性 (用例 1-2)

用例 1: 客户端 SDK 启动时，正确拉起 Ngrok 并注册到 Hub
用例 2: 验证 identity.md 物理隔离生效
"""
import pytest
from pathlib import Path
from agent_hub_client import HubConnector, NgrokManager
from agent_hub_client.config import DEFAULT_IDENTITY_FILE


@pytest.mark.asyncio
class TestIsolation:
    """隔离与连通性测试"""

    async def test_ngrok_tunnel_starts_and_registers(self):
        """
        用例 1: 验证 Ngrok 隧道正确启动
        """
        manager = NgrokManager()

        # 启动隧道
        public_url = manager.start_tunnel(8000)

        # 验证 URL 格式
        assert public_url.startswith("https://")
        assert "ngrok" in public_url or "ngrok-free.app" in public_url

        # 清理
        manager.stop_tunnel()

    async def test_identity_file_isolation(self, tmp_path):
        """
        用例 2: 验证 identity.md 物理隔离
        确保 System Prompt 不会被上传到 Hub
        """
        # 1. 创建测试 identity.md
        identity_file = tmp_path / "identity.md"
        identity_content = """
        # 测试名片

        这是公开的名片信息。

        ## 私密信息（不应该在请求中出现）
        SECRET_API_KEY=sk-1234567890
        """
        identity_file.write_text(identity_content)

        # 2. 读取名片内容
        content = identity_file.read_text()

        # 3. 验证：名片内容不包含敏感关键字
        # 这里只是一个示例，实际验证应该在发送请求时检查
        assert "测试名片" in content

        # 4. 验证：当发布到 Hub 时，只发送 identity.md 内容
        # 而不是整个 System Prompt
        # 这个测试需要 mock HTTP 请求来验证
        # TODO: 添加实际的网络请求验证


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
