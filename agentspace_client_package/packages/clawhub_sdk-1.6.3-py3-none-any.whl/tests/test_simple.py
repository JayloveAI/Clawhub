"""
AgentHub V1.5 Simple Unit Tests
================================
Tests that can run without the Hub server
"""
# Windows UTF-8 fix MUST come before Rich import
import sys
import io

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8')

import asyncio
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


class MockAgent:
    """Mock Agent for testing"""
    
    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        self.tasks_received = []
    
    async def handle_task(self, task_type: str, context: dict):
        """Mock task handler"""
        self.tasks_received.append({
            "type": task_type,
            "context": context,
            "timestamp": asyncio.get_event_loop().time()
        })
        
        # Simulate processing
        await asyncio.sleep(0.1)
        
        return {
            "status": "completed",
            "agent": self.agent_id,
            "task_type": task_type,
            "result": f"Processed: {task_type}"
        }


async def test_task_processing():
    """Test basic task processing"""
    print("\n=== Test 1: Task Processing ===\n")
    
    agent = MockAgent("test_agent")
    
    # Send some tasks
    tasks = [
        ("clean_text", {"text": "Hello World"}),
        ("format_markdown", {"text": "# Test"}),
        ("analyze_data", {"data": [1, 2, 3]})
    ]
    
    for task_type, context in tasks:
        result = await agent.handle_task(task_type, context)
        print(f"  [OK] {task_type}: {result['result']}")
    
    assert len(agent.tasks_received) == 3
    print(f"\n[Tasks received: {len(agent.tasks_received)}]\n")


async def test_concurrent_tasks():
    """Test concurrent task handling"""
    print("=== Test 2: Concurrent Tasks ===\n")
    
    agent = MockAgent("concurrent_agent")
    
    # Send tasks concurrently
    tasks = [
        agent.handle_task("task_1", {"data": 1}),
        agent.handle_task("task_2", {"data": 2}),
        agent.handle_task("task_3", {"data": 3}),
        agent.handle_task("task_4", {"data": 4}),
        agent.handle_task("task_5", {"data": 5})
    ]
    
    results = await asyncio.gather(*tasks)
    
    print(f"  [OK] Completed {len(results)} concurrent tasks")
    assert len(agent.tasks_received) == 5
    print()


async def test_status_updates():
    """Test status update logic"""
    print("=== Test 3: Status Updates ===\n")
    
    # Simulate status states
    statuses = ["active", "busy", "offline"]
    broadcasts = [
        "Ready for tasks",
        "Processing batch #123",
        "Maintenance mode"
    ]
    
    for status, broadcast in zip(statuses, broadcasts):
        print(f"  [->] Status: [{status}] {broadcast}")
        await asyncio.sleep(0.1)
    
    print("\n  [OK] Status cycle completed\n")


async def run_all_tests():
    """Run all simple tests"""
    print("=" * 55)
    print("  AgentHub V1.5 Simple Tests")
    print("=" * 55)
    print("\nThese tests run without requiring the Hub server.\n")
    
    try:
        await test_task_processing()
        await test_concurrent_tasks()
        await test_status_updates()
        
        # Summary
        print("\n" + "=" * 55)
        print("  All Tests Passed! OK")
        print("=" * 55 + "\n")
        
    except AssertionError as e:
        print(f"\n[FAIL] Test Failed: {e}")
        raise
    except Exception as e:
        print(f"\n[ERROR] {e}")
        raise


if __name__ == "__main__":
    asyncio.run(run_all_tests())
